module.exports = Object.freeze({
    DB_HOST : '',
    DB_USER : '',
    DB_PWD : '',
    DB_DATABASE : ''
});