export const theme = {
  primaryDark: '#020213',
  primaryLight: '#0A0128',
  primaryHover: '#343078',
  mobile: '576px',
}
