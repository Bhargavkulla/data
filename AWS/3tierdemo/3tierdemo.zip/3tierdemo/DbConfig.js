module.exports = Object.freeze({
    DB_HOST : 'three-tier-db.cluster-cb6eiuesce5w.us-east-1.rds.amazonaws.com',
    DB_USER : 'admin',
    DB_PWD : 'adminadmin',
    DB_DATABASE : 'webappdb'
});

